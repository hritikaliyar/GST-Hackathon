The purpose of this Hackathon is to engage Indian students, researchers, and innovators in developing advanced, data-driven AI and ML solutions based on given data set. 
Participants will have access to a comprehensive data set containing approximately 900,000 records, each with around 21 attributes and target variables. 
This data is anonymized, meticulously labeled, and includes training, testing, and a non-validated subset reserved specifically for final evaluations by the GSTN.
